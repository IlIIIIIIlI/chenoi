# game options settings
TITLE = "Packmaz!"
WIDTH = 460
HEIGHT = 600
FPS = 30

# define colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
LIGHTBLUE = (0, 155, 155)
YELLOW = (255, 255, 0)
GREY = (169,169,169)
ORANGE = (255,165,0)
PINK = (255,192,203)
